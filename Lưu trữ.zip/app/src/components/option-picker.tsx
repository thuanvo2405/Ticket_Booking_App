"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Filter } from "lucide-react";
import { useSearchStore } from "@/store/useSearchStore";
import { useQuery } from "@tanstack/react-query";
import { getEventTypesAPI } from "@/services/eventService";

type FilterData = {
  area?: string;
  type?: string;
};

interface OptionPickerProps {
  onApply?: (data: FilterData) => void;
}

export default function OptionPicker({ onApply }: OptionPickerProps) {
  const [open, setOpen] = useState(false);
  const area = useSearchStore((state) => state.area);
  const eventType = useSearchStore((state) => state.eventType);
  const setEventType = useSearchStore((state) => state.setEventType);
  const setArea = useSearchStore((state) => state.setArea);
  const [tempArea, setTempArea] = useState(area);
  const [tempType, setTempType] = useState(eventType);
  const { data: categories } = useQuery({
    queryKey: ["publicEventCategories"],
    queryFn: () => getEventTypesAPI(),
  });

  const categoryOptions = categories?.map((c: any) => c.tenloaisukien) || [
    "Âm Nhạc",
    "Sân Khấu",
    "Thể Thao",
    "Workshop",
    "Khác",
  ];
  const handleReset = () => {
    setTempArea("");
    setTempType("");
  };

  const handleApply = () => {
    setArea(tempArea);
    setEventType(tempType);

    onApply?.({
      area: tempArea,
      type: tempType,
    });
    setOpen(false);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Filter className="w-4 h-4" />
          Bộ lọc
        </Button>
      </PopoverTrigger>

      <PopoverContent className="w-80 space-y-5">
        <div>
          <p className="font-semibold mb-2">Khu vực</p>
          <RadioGroup value={tempArea} onValueChange={setTempArea}>
            {["Toàn quốc", "Hồ Chí Minh", "Hà Nội", "Đà Nẵng", "Khác"].map(
              (item, i) => (
                <div key={i} className="flex items-center space-x-2">
                  <RadioGroupItem
                    value={item}
                    defaultValue={tempArea}
                    id={`area-${i}`}
                  />
                  <Label htmlFor={`area-${i}`}>{item}</Label>
                </div>
              )
            )}
          </RadioGroup>
        </div>

        <div>
          <p className="font-semibold mb-2">Thể loại</p>
          <RadioGroup value={tempType} onValueChange={setTempType}>
            {categoryOptions.map((item: any, i: number) => (
              <div key={item} className="flex items-center space-x-2">
                <RadioGroupItem value={item} id={`type-${i}`} />
                <Label htmlFor={`type-${i}`}>{item}</Label>
              </div>
            ))}
          </RadioGroup>
        </div>

        <div className="flex justify-between pt-3 border-t">
          <Button variant="outline" onClick={handleReset}>
            Thiết lập lại
          </Button>
          <Button onClick={handleApply}>Áp dụng</Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
